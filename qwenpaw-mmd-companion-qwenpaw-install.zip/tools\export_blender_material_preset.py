import argparse
import json
import os
import shutil
import sys
from pathlib import Path

import bpy


def color_value(value, fallback=None):
    if value is None:
        return fallback
    try:
        return [float(value[i]) for i in range(min(len(value), 4))]
    except Exception:
        return fallback


def linked_image(socket):
    if socket is None:
        return None
    for link in socket.links:
        node = link.from_node
        if node.bl_idname == "ShaderNodeTexImage" and node.image:
            return node.image
    return None


def image_path(image, output_textures):
    source = bpy.path.abspath(image.filepath) if image.filepath else ""
    if not source or not os.path.exists(source):
        return None

    ext = Path(source).suffix or ".png"
    safe_name = f"{image.name.replace('/', '_').replace('\\\\', '_')}{ext}"
    dest = output_textures / safe_name
    if not dest.exists():
        shutil.copy2(source, dest)
    return f"textures/{safe_name}"


def material_to_preset(material, output_textures):
    entry = {
        "name": material.name,
        "blendMethod": material.blend_method,
        "useNodes": material.use_nodes,
    }

    if not material.use_nodes or not material.node_tree:
        entry.update({
            "color": color_value(material.diffuse_color, [1, 1, 1, 1]),
            "opacity": float(material.diffuse_color[3]) if len(material.diffuse_color) > 3 else 1,
        })
        return entry

    principled = None
    for node in material.node_tree.nodes:
        if node.bl_idname == "ShaderNodeBsdfPrincipled":
            principled = node
            break

    if principled:
        sockets = principled.inputs
        base_color = sockets.get("Base Color")
        alpha = sockets.get("Alpha")
        emission_color = sockets.get("Emission Color") or sockets.get("Emission")
        emission_strength = sockets.get("Emission Strength")
        roughness = sockets.get("Roughness")
        metallic = sockets.get("Metallic")
        normal = sockets.get("Normal")

        entry["color"] = color_value(getattr(base_color, "default_value", None), [1, 1, 1, 1])
        entry["opacity"] = float(getattr(alpha, "default_value", 1))
        entry["emissive"] = color_value(getattr(emission_color, "default_value", None), [0, 0, 0, 1])
        entry["emissiveIntensity"] = float(getattr(emission_strength, "default_value", 0))
        entry["roughness"] = float(getattr(roughness, "default_value", 0.5))
        entry["metallic"] = float(getattr(metallic, "default_value", 0))

        texture_slots = {
            "map": linked_image(base_color),
            "alphaMap": linked_image(alpha),
            "emissiveMap": linked_image(emission_color),
            "normalMap": linked_image(normal),
        }
        for key, image in texture_slots.items():
            if image:
                path = image_path(image, output_textures)
                if path:
                    entry[key] = path

    entry["nodes"] = []
    for node in material.node_tree.nodes:
        entry["nodes"].append({
            "name": node.name,
            "type": node.bl_idname,
            "label": node.label,
        })

    return entry


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--blend", required=True)
    parser.add_argument("--out", required=True)
    argv = sys.argv
    args = parser.parse_args(argv[argv.index("--") + 1:] if "--" in argv else None)

    blend_path = Path(args.blend)
    output_dir = Path(args.out)
    texture_dir = output_dir / "textures"
    output_dir.mkdir(parents=True, exist_ok=True)
    texture_dir.mkdir(parents=True, exist_ok=True)

    bpy.ops.wm.open_mainfile(filepath=str(blend_path))

    preset = {
        "schema": "qwenpaw-mmd-material-preset/v1",
        "source": str(blend_path),
        "name": blend_path.stem,
        "materials": {},
    }

    for material in bpy.data.materials:
        preset["materials"][material.name] = material_to_preset(material, texture_dir)

    with open(output_dir / "preset.json", "w", encoding="utf-8") as f:
        json.dump(preset, f, ensure_ascii=False, indent=2)

    print(f"Exported {len(preset['materials'])} materials to {output_dir}")


if __name__ == "__main__":
    main()
