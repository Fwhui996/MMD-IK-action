@echo off
setlocal
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\update-qwenpaw-plugin.ps1" %*
if errorlevel 1 (
  echo.
  echo Update failed.
  pause
  exit /b 1
)

echo.
echo Update finished.
pause
