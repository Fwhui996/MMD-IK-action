import fs from 'node:fs';
import { MMDParser } from '../renderers/three-modern/node_modules/three/examples/jsm/libs/mmdparser.module.js';

const pmx = process.argv[2];
if (!pmx) {
  console.error('Usage: node tools/inspect-pmx-physics.mjs <model.pmx>');
  process.exit(1);
}

const buffer = fs.readFileSync(pmx).buffer;
const parser = new MMDParser.Parser();
const data = parser.parsePmx(buffer, true);
const bones = data.bones || [];
const bodies = data.rigidBodies || [];
const constraints = data.constraints || [];

const patterns = [
  '\u8db3', '\u811a', '\u817f', '\u3072\u3056', '\u819d', '\u8db3\u9996',
  '\u3064\u307e\u5148', 'toe', 'knee', 'leg', 'ankle', 'foot',
  '\u88d9', '\u30b9\u30ab\u30fc\u30c8', 'skirt', '\u8896',
  '\u9aea', 'hair', '\u8155', '\u8170', '\u5c3b', 'body', '\u4e0b\u534a\u8eab',
];

function isInteresting(text) {
  const lower = String(text || '').toLowerCase();
  return patterns.some((pattern) => lower.includes(pattern.toLowerCase()));
}

const byBone = new Map();
for (let i = 0; i < bodies.length; i++) {
  const body = bodies[i];
  const arr = byBone.get(body.boneIndex) || [];
  arr.push({ index: i, ...body });
  byBone.set(body.boneIndex, arr);
}

const lines = [];
lines.push(JSON.stringify({
  pmx,
  boneCount: bones.length,
  rigidBodyCount: bodies.length,
  constraintCount: constraints.length,
  typeCounts: bodies.reduce((acc, body) => {
    acc[body.type] = (acc[body.type] || 0) + 1;
    return acc;
  }, {}),
}, null, 2));

lines.push('\nBones 70-110:');
for (let i = 70; i <= 110 && i < bones.length; i++) {
  lines.push(`${i}\t${bones[i].name}\tparent=${bones[i].parentIndex}\tgrant=${JSON.stringify(bones[i].grant || null)}`);
}

lines.push('\nTail bones:');
for (let i = Math.max(0, bones.length - 50); i < bones.length; i++) {
  lines.push(`${i}\t${bones[i].name}\tparent=${bones[i].parentIndex}\tgrant=${JSON.stringify(bones[i].grant || null)}`);
}

lines.push('\nInteresting rigid bodies:');
for (let i = 0; i < bodies.length; i++) {
  const body = bodies[i];
  const bone = bones[body.boneIndex];
  if (!isInteresting(`${body.name} ${bone?.name || ''}`)) continue;
  lines.push(`#${i}\t${body.name}\ttype=${body.type}\tbone=${body.boneIndex}:${bone?.name || '-'}\tshape=${body.shapeType}\tsize=${body.width},${body.height},${body.depth}\tpos=${body.position?.join(',')}\trot=${body.rotation?.join(',')}\tgroup=${body.groupIndex}\tmask=${body.groupTarget}`);
}

lines.push('\nBones that have multiple rigid body types:');
for (const [boneIndex, arr] of byBone.entries()) {
  const types = [...new Set(arr.map((body) => body.type))].sort();
  if (types.length <= 1) continue;
  lines.push(`${boneIndex}:${bones[boneIndex]?.name || '-'} types=${types.join('/')} bodies=${arr.map((body) => `#${body.index}:${body.name}:t${body.type}`).join(' | ')}`);
}

lines.push('\nConstraints touching interesting bodies:');
for (let i = 0; i < constraints.length; i++) {
  const constraint = constraints[i];
  const a = bodies[constraint.rigidBodyIndex1];
  const b = bodies[constraint.rigidBodyIndex2];
  const text = `${constraint.name} ${a?.name || ''} ${b?.name || ''} ${bones[a?.boneIndex]?.name || ''} ${bones[b?.boneIndex]?.name || ''}`;
  if (!isInteresting(text)) continue;
  lines.push(`#${i}\t${constraint.name}\t${constraint.rigidBodyIndex1}:${a?.name}:t${a?.type}:bone${a?.boneIndex}:${bones[a?.boneIndex]?.name || '-'} <-> ${constraint.rigidBodyIndex2}:${b?.name}:t${b?.type}:bone${b?.boneIndex}:${bones[b?.boneIndex]?.name || '-'}`);
}

console.log(lines.join('\n'));
