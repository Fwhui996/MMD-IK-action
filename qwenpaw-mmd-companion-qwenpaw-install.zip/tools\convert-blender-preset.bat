@echo off
setlocal

set "ROOT=%~dp0.."
set "ZIP=%~1"
if "%ZIP%"=="" (
  echo Usage:
  echo   tools\convert-blender-preset.bat "C:\path\preset.zip"
  exit /b 1
)

set "BLENDER=%BLENDER_EXE%"
if "%BLENDER%"=="" (
  for %%P in (
    "%ProgramFiles%\Blender Foundation\Blender 4.3\blender.exe"
    "%ProgramFiles%\Blender Foundation\Blender 4.2\blender.exe"
    "%ProgramFiles%\Blender Foundation\Blender 4.1\blender.exe"
    "%ProgramFiles%\Blender Foundation\Blender 4.0\blender.exe"
    "%ProgramFiles%\Blender Foundation\Blender 3.6\blender.exe"
  ) do (
    if exist "%%~P" set "BLENDER=%%~P"
  )
)

if "%BLENDER%"=="" (
  echo Blender not found.
  echo Install Blender or set BLENDER_EXE, for example:
  echo   set BLENDER_EXE="D:\blander\blender-launcher.exe"
  exit /b 1
)

set "WORK=%ROOT%\runtime\blender-preset-work"
set "OUT=%ROOT%\runtime\material-presets"
if not exist "%WORK%" mkdir "%WORK%"
if not exist "%OUT%" mkdir "%OUT%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$zip = Resolve-Path -LiteralPath '%ZIP%';" ^
  "$work = Resolve-Path -LiteralPath '%WORK%';" ^
  "Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue;" ^
  "New-Item -ItemType Directory -Path $work | Out-Null;" ^
  "Expand-Archive -LiteralPath $zip -DestinationPath $work -Force;" ^
  "$blend = Get-ChildItem -LiteralPath $work -Recurse -Filter *.blend | Select-Object -First 1;" ^
  "if (-not $blend) { throw 'No .blend file found in zip.' };" ^
  "$name = [IO.Path]::GetFileNameWithoutExtension($blend.Name);" ^
  "$out = Join-Path (Resolve-Path -LiteralPath '%OUT%') $name;" ^
  "New-Item -ItemType Directory -Force -Path $out | Out-Null;" ^
  "Set-Content -LiteralPath (Join-Path $work 'blend-path.txt') -Value $blend.FullName -Encoding UTF8;" ^
  "Set-Content -LiteralPath (Join-Path $work 'out-path.txt') -Value $out -Encoding UTF8;"

if errorlevel 1 exit /b 1

set /p BLEND=<"%WORK%\blend-path.txt"
set /p PRESET_OUT=<"%WORK%\out-path.txt"

"%BLENDER%" --background --python "%ROOT%\tools\export_blender_material_preset.py" -- --blend "%BLEND%" --out "%PRESET_OUT%"
if errorlevel 1 exit /b 1

echo.
echo Done.
echo Output: %PRESET_OUT%
echo Preset: %PRESET_OUT%\preset.json
