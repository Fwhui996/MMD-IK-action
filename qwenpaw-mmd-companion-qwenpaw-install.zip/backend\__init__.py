"""MMD companion backend package."""
