param(
  [string]$Port = "9333",
  [string]$Expression
)

$tabs = Invoke-RestMethod "http://127.0.0.1:$Port/json"
$tab = $tabs | Where-Object { $_.url -like 'http://127.0.0.1:5178/*' } | Select-Object -First 1
if (-not $tab) { throw "Renderer tab not found on port $Port" }

$ws = [System.Net.WebSockets.ClientWebSocket]::new()
$uri = [Uri]$tab.webSocketDebuggerUrl
$ws.ConnectAsync($uri, [Threading.CancellationToken]::None).GetAwaiter().GetResult()

function Send-Cdp($ws, [int]$id, [string]$method, $params) {
  $payload = @{ id = $id; method = $method; params = $params } | ConvertTo-Json -Depth 20 -Compress
  $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
  $segment = [ArraySegment[byte]]::new($bytes)
  $ws.SendAsync($segment, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).GetAwaiter().GetResult()
}

function Receive-Cdp($ws) {
  $buffer = New-Object byte[] 1048576
  $builder = [Text.StringBuilder]::new()
  do {
    $segment = [ArraySegment[byte]]::new($buffer)
    $result = $ws.ReceiveAsync($segment, [Threading.CancellationToken]::None).GetAwaiter().GetResult()
    [void]$builder.Append([Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count))
  } while (-not $result.EndOfMessage)
  $builder.ToString() | ConvertFrom-Json
}

function Invoke-Cdp($ws, [int]$id, [string]$method, $params) {
  Send-Cdp $ws $id $method $params
  while ($true) {
    $message = Receive-Cdp $ws
    if ($message.id -eq $id) { return $message }
  }
}

$id = 1
Invoke-Cdp $ws $id "Runtime.enable" @{} | Out-Null
$id++
$result = Invoke-Cdp $ws $id "Runtime.evaluate" @{
  expression = $Expression
  awaitPromise = $true
  returnByValue = $true
}

$ws.Dispose()
$result | ConvertTo-Json -Depth 20
