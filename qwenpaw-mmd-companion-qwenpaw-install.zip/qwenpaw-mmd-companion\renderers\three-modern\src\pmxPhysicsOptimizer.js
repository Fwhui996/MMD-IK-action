const VERSION = 3;
const CACHE_KEY = 'qwenpaw-mmd-physics-optimizer/v3';

const BODY_KEYWORDS = [
  '\u982d', '\u9996', '\u4e0a\u534a\u8eab', '\u4e0b\u534a\u8eab',
  '\u80f8', '\u8170', '\u80a9', '\u8155', '\u3072\u3058', '\u8098',
  '\u624b\u9996', '\u624b', '\u8db3', '\u3072\u3056', '\u819d',
  '\u8db3\u9996', '\u3064\u307e\u5148', '\u9aa8\u76e4', '\u80a1',
  '\u592a\u3082\u3082', '\u3059\u306d', '\u8e35',
  'head', 'neck', 'upper', 'lower', 'chest', 'waist', 'shoulder',
  'hip', 'pelvis', 'thigh', 'shin', 'calf', 'heel',
  'arm', 'elbow', 'wrist', 'hand', 'leg', 'knee', 'ankle', 'toe',
];

const SOFT_KEYWORDS = [
  '\u9aea', '\u524d\u9aea', '\u5f8c\u9aea', '\u6a2a\u9aea',
  '\u30b9\u30ab\u30fc\u30c8', '\u8896', '\u670d', '\u88fe',
  '\u30de\u30f3\u30c8', '\u30ea\u30dc\u30f3', '\u98fe', '\u7d10',
  '\u30c1\u30a7\u30fc\u30f3', '\u30d9\u30eb',
  'hair', 'skirt', 'sleeve', 'cloth', 'ribbon', 'accessory', 'chain', 'belt',
];

export function optimizePmxPhysics(mesh, options = {}) {
  const mmd = mesh?.geometry?.userData?.MMD;
  const rigidBodies = mmd?.rigidBodies || [];
  if (!rigidBodies.length) {
    return { ok: false, reason: 'no_rigid_bodies', changed: 0, total: 0 };
  }

  const modelId = options.modelId || mesh?.uuid || 'unknown';
  const cacheId = `v${VERSION}:${modelId}`;
  const cached = options.useCache !== false ? readCache()[cacheId] : null;
  const report = cached?.version === VERSION && Array.isArray(cached.patches)
    ? applyCachedPatches(rigidBodies, cached.patches)
    : buildAndApplyPatches(rigidBodies, mmd.bones || []);

  if (report.source === 'analysis' && options.useCache !== false && report.patches.length) {
    const cache = readCache();
    cache[cacheId] = { version: VERSION, patches: report.patches };
    writeCache(cache);
  }

  mmd.physicsOptimization = {
    version: VERSION,
    modelId,
    source: report.source,
    changed: report.changed,
    total: report.total,
    categories: report.categories,
  };

  return report;
}

function buildAndApplyPatches(rigidBodies, bones) {
  const patches = [];
  const categories = { body: 0, soft: 0, unknown: 0 };

  for (let index = 0; index < rigidBodies.length; index++) {
    const rb = rigidBodies[index];
    const bone = rb.boneIndex >= 0 ? bones[rb.boneIndex] : null;
    const category = classify(`${rb.name || ''} ${bone?.name || ''}`, rb);
    categories[category]++;
    const patch = makePatch(index, rb, category);
    if (patch) patches.push(patch);
  }

  return {
    ok: true,
    source: 'analysis',
    changed: applyPatches(rigidBodies, patches),
    total: rigidBodies.length,
    patches,
    categories,
  };
}

function makePatch(index, rb, category) {
  const values = {};

  if (category === 'body') {
    const profile = bodyProfile(rb);
    const shrink = profile.shrink;
    if (shrink < 1 && rb.width > 0) values.width = clamp(rb.width * shrink, 0.04, rb.width);
    if (rb.shapeType === 1) {
      if (rb.height > 0) values.height = clamp(rb.height * shrink, 0.04, rb.height);
      if (rb.depth > 0) values.depth = clamp(rb.depth * shrink, 0.04, rb.depth);
    } else if (rb.height > 0) {
      values.height = clamp(rb.height * profile.heightShrink, 0.04, rb.height);
    }
    raise(values, rb, 'positionDamping', profile.positionDamping);
    raise(values, rb, 'rotationDamping', profile.rotationDamping);
    lower(values, rb, 'restitution', 0.02);
    lower(values, rb, 'friction', 0.44);
  } else if (category === 'soft') {
    raise(values, rb, 'positionDamping', isSmall(rb) ? 0.92 : 0.76);
    raise(values, rb, 'rotationDamping', isSmall(rb) ? 0.96 : 0.86);
    lower(values, rb, 'restitution', 0.008);
    lower(values, rb, 'friction', 0.36);
  } else if (isSmall(rb)) {
    raise(values, rb, 'positionDamping', 0.84);
    raise(values, rb, 'rotationDamping', 0.92);
    lower(values, rb, 'restitution', 0.008);
    lower(values, rb, 'friction', 0.38);
  }

  return Object.keys(values).length ? { index, values } : null;
}

function bodyProfile(rb) {
  if (isSmall(rb)) {
    return {
      shrink: 0.965,
      heightShrink: 0.98,
      positionDamping: 0.64,
      rotationDamping: 0.74,
    };
  }

  return {
    shrink: rb.type === 0 ? 0.92 : 0.965,
    heightShrink: rb.type === 0 ? 0.968 : 0.985,
    positionDamping: 0.66,
    rotationDamping: 0.78,
  };
}

function applyCachedPatches(rigidBodies, patches) {
  return {
    ok: true,
    source: 'cache',
    changed: applyPatches(rigidBodies, patches),
    total: rigidBodies.length,
    patches,
    categories: { body: 0, soft: 0, unknown: 0 },
  };
}

function applyPatches(rigidBodies, patches) {
  let changed = 0;
  for (const patch of patches) {
    const rb = rigidBodies[patch.index];
    if (!rb) continue;
    Object.assign(rb, patch.values);
    changed++;
  }
  return changed;
}

function classify(name, rb) {
  const lower = String(name || '').toLowerCase();
  if (hasKeyword(lower, SOFT_KEYWORDS)) return 'soft';
  if (rb.type === 0 && !isTiny(rb)) return 'body';
  if (hasKeyword(lower, BODY_KEYWORDS) && !isTiny(rb)) return 'body';
  return 'unknown';
}

function hasKeyword(text, keywords) {
  return keywords.some((keyword) => text.includes(String(keyword).toLowerCase()));
}

function isSmall(rb) {
  return Math.max(rb.width || 0, rb.height || 0, rb.depth || 0) < 0.7;
}

function isTiny(rb) {
  return Math.max(rb.width || 0, rb.height || 0, rb.depth || 0) < 0.25;
}

function raise(values, rb, key, minValue) {
  if (numberOr(rb[key], 0) < minValue) values[key] = minValue;
}

function lower(values, rb, key, maxValue) {
  if (numberOr(rb[key], 0) > maxValue) values[key] = maxValue;
}

function numberOr(value, fallback) {
  return Number.isFinite(value) ? value : fallback;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function readCache() {
  try {
    const raw = window.localStorage?.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeCache(cache) {
  try {
    window.localStorage?.setItem(CACHE_KEY, JSON.stringify(cache));
  } catch {}
}
