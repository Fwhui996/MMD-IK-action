param(
  [string]$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path,
  [string]$InstallRoot = "$env:USERPROFILE\.copaw\plugins\qwenpaw-mmd-companion",
  [string]$QwenPawPython = "E:\copaw\QwenPaw\python.exe",
  [string]$ZipPath = "E:\MMDdongbu\qwenpaw-mmd-companion-qwenpaw-install.zip",
  [int]$BridgePort = 8098,
  [switch]$NoBuild,
  [switch]$NoRestart,
  [switch]$NoZip
)

$ErrorActionPreference = 'Stop'

function Write-Step($message) {
  Write-Host ""
  Write-Host "==> $message" -ForegroundColor Cyan
}

function Remove-IfExists($path) {
  if (Test-Path -LiteralPath $path) {
    Remove-Item -LiteralPath $path -Recurse -Force
  }
}

function Copy-DirectoryFresh($source, $destination) {
  Remove-IfExists $destination
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
}

if (!(Test-Path -LiteralPath $ProjectRoot)) {
  throw "ProjectRoot does not exist: $ProjectRoot"
}

$frontendRoot = Join-Path $ProjectRoot 'renderers\three-modern'
$distRoot = Join-Path $frontendRoot 'dist'
$installedDist = Join-Path $InstallRoot 'renderers\three-modern\dist'
$installedBackend = Join-Path $InstallRoot 'backend'
$sourceBackend = Join-Path $ProjectRoot 'backend'
$installedPluginJson = Join-Path $InstallRoot 'plugin.json'
$sourcePluginJson = Join-Path $ProjectRoot 'plugin.json'

Write-Host "Project: $ProjectRoot"
Write-Host "Install: $InstallRoot"
Write-Host "Zip:     $ZipPath"

if (!$NoBuild) {
  Write-Step "Building frontend"
  Push-Location $frontendRoot
  try {
    npm run build
  } finally {
    Pop-Location
  }
}

if (!(Test-Path -LiteralPath $distRoot)) {
  throw "Frontend dist does not exist: $distRoot"
}

Write-Step "Updating installed plugin files"
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
Copy-DirectoryFresh $distRoot $installedDist
Copy-DirectoryFresh $sourceBackend $installedBackend
Copy-Item -LiteralPath $sourcePluginJson -Destination $installedPluginJson -Force

if (!$NoRestart) {
  Write-Step "Restarting bridge on port $BridgePort"
  $listeners = Get-NetTCPConnection -LocalPort $BridgePort -State Listen -ErrorAction SilentlyContinue
  if ($listeners) {
    $pids = $listeners | Select-Object -ExpandProperty OwningProcess -Unique
    foreach ($pidValue in $pids) {
      Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Milliseconds 500
  }

  $desktopApp = Join-Path $InstallRoot 'backend\desktop_app.py'
  if (!(Test-Path -LiteralPath $QwenPawPython)) {
    throw "QwenPaw Python does not exist: $QwenPawPython"
  }
  if (!(Test-Path -LiteralPath $desktopApp)) {
    throw "desktop_app.py does not exist: $desktopApp"
  }

  Start-Process -FilePath $QwenPawPython -ArgumentList @(
    $desktopApp,
    '--host', '127.0.0.1',
    '--port', "$BridgePort"
  ) -WindowStyle Hidden

  Start-Sleep -Seconds 2
  try {
    $health = Invoke-WebRequest "http://127.0.0.1:$BridgePort/health" -UseBasicParsing
    Write-Host $health.Content
  } catch {
    Write-Warning "Bridge started, but health check failed: $($_.Exception.Message)"
  }
}

if (!$NoZip) {
  Write-Step "Packaging install zip"
  $stage = Join-Path (Split-Path -Parent $ZipPath) '_qwenpaw_mmd_companion_zip_stage'
  Remove-IfExists $stage
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  $stagePlugin = Join-Path $stage 'qwenpaw-mmd-companion'

  robocopy $ProjectRoot $stagePlugin /E /XD .git node_modules runtime __pycache__ /XF *.pyc | Out-Null
  if ($LASTEXITCODE -ge 8) {
    throw "robocopy failed with exit code $LASTEXITCODE"
  }

  Remove-IfExists $ZipPath
  Compress-Archive -Path $stagePlugin -DestinationPath $ZipPath -Force
  Remove-IfExists $stage
}

Write-Step "Done"
if (Test-Path -LiteralPath $installedDist) {
  Get-Content -LiteralPath (Join-Path $installedDist 'index.html') | Write-Host
}
if (Test-Path -LiteralPath $ZipPath) {
  Get-Item -LiteralPath $ZipPath | Select-Object FullName, Length, LastWriteTime | Format-List
}
